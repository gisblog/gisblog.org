### Medicine Outreach (2014) ###

See http://gisblog.org/.

Air-gap mapping for Africa
