### Monty Hall: Stay or Switch Your Pick? ###

[ ♠ ] [ ♥ ] [ ♣ ]

See http://gisblog.org/.

Related:
* [Introduction to Probability – Monty Hall – courses – MIT](http://web.mit.edu/rsi/www/2013/files/MiniSamples/MontyHall/montymain.pdf)
* [The Monty Hall Problem: A Study – MIT](http://courses.csail.mit.edu/6.042/fall05/ln12.pdf)
* [Wolfram](http://mathworld.wolfram.com/MontyHallProblem.html)
* [Mersenne Twister (for creating random positions)](http://en.wikipedia.org/wiki/Mersenne_twister)
